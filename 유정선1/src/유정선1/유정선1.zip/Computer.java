package 유정선1;

public class Computer extends Product{
	public Computer() {
		super(200, "Computer");
	}

}
