package 유정선1;

public class TV extends Product{
	public TV() {
		super(100, "TV");
	}

}
