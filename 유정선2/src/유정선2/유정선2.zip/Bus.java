package 유정선2;

public class Bus extends Transportation{
	public Bus(int n) {
		super(n,1300);
	}
	
}
