package 유정선2;

public class Subway extends Transportation{
	public Subway(int n) {
		super(n,1500);
	}
	

}
